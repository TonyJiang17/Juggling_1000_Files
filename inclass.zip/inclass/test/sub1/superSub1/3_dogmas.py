def getFive():
    return 5